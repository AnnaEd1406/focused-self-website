Netlify Function (contact) instructions:

- Deploy this function to Netlify under /netlify/functions/contact
- Set env vars in Netlify dashboard:
  - SENDGRID_API_KEY (your SendGrid API key)
  - SENDGRID_TO_EMAIL (email to receive messages)
- From the site, POST JSON to /.netlify/functions/contact
Example fetch:
fetch('/.netlify/functions/contact', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({name:'A', email:'a@b.com', message:'Hi'}) })
