// Netlify Function example: /netlify/functions/contact.js
// This function expects a POST with JSON: { name, email, message }
// Configure SENDGRID_API_KEY in Netlify environment variables and set SENDGRID_TO_EMAIL
const fetch = require('node-fetch');
exports.handler = async function(event, context) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }
  const data = JSON.parse(event.body);
  const { name, email, message } = data;
  // Basic validation
  if (!name || !email || !message) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Missing fields' }) };
  }
  // Send email via SendGrid
  const SENDGRID_API_KEY = process.env.SENDGRID_API_KEY;
  const SENDGRID_TO = process.env.SENDGRID_TO_EMAIL;
  const payload = {
    personalizations: [{ to: [{ email: SENDGRID_TO }] }],
    from: { email: email },
    subject: `Website enquiry from ${name}`,
    content: [{ type: 'text/plain', value: message }]
  };
  const resp = await fetch('https://api.sendgrid.com/v3/mail/send', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${SENDGRID_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  if (resp.status >= 200 && resp.status < 300) {
    return { statusCode: 200, body: JSON.stringify({ ok: true }) };
  } else {
    const text = await resp.text();
    return { statusCode: resp.status, body: text };
  }
};